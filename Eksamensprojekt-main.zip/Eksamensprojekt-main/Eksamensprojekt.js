
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
let coord = {x: 0, y: 0};